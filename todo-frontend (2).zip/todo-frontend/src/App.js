import { useEffect, useState } from "react";
import TodoForm from "./components/TodoForm";
import TodoList from "./components/TodoList";
import api from "./services/todoService";
import "./App.css";

function App() {
  const [todos, setTodos] = useState([]);

  const loadTodos = async () => {
    try {
      const res = await api.getAll();
      setTodos(res.data);
    } catch (err) {
      console.error("Failed to load todos:", err);
    }
  };

  useEffect(() => {
    loadTodos();
  }, []);

  const addTodo = async (todo) => {
    await api.create(todo);
    loadTodos();
  };

  const deleteTodo = async (id) => {
    await api.remove(id);
    loadTodos();
  };

  const toggleTodo = async (todo) => {
    await api.update(todo.id, { ...todo, completed: !todo.completed });
    loadTodos();
  };

  const updateTodo = async (id, data) => {
    await api.update(id, data);
    loadTodos();
  };

  return (
    <div className="app">
      <h1>✅ My Custom Todo Manager</h1>
      <TodoForm onAdd={addTodo} />
      <TodoList
        todos={todos}
        onDelete={deleteTodo}
        onToggle={toggleTodo}
        onUpdate={updateTodo}
      />
    </div>
  );
}

export default App;